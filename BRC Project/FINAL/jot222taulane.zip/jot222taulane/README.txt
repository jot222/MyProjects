jot222taulane directory
 - data_generation/
	 createProducts.java
	 createPeople.java
 - jot222/
	Interface.java
	Interface.class
	jot222.jar
	Manifest.txt
	ojdbc8,jar
  - README.txt


For the Interface.java source file
  To compile on sunlab: javac Inteface.java
  To run on sunlab: java -cp "./:./ojdbc8.jar" jot222 

In order to run the jot222.jar executable
  GO TO the jot222 directory
  Run: java -jar jot222.jar

Running the Executable
  Enter oracle username and password when immediately prompted. There are 3 user interfaces.
  1. BRC Manager
	-This interface allows the manager to login with their store number(Use 1-6) and can allows them to check inventory, order more inventory, or input new products into the database

  2. Existing customer login
	-This interface allows a customer that has already shopped with BRC before to login and either continue a previous shopping trip or start a new one.
	-When prompted for a customer ID I recommend you use 1 if you want to continue a shopping trip or 100 to use a customer that has no previous cart history
	-The user can then browse the store by categories, add and remove items to the cart, save and quit, or checkout whatever is in the cart

  3. New customer signup
	-The user can sign up a new customer and begin shopping that way.
